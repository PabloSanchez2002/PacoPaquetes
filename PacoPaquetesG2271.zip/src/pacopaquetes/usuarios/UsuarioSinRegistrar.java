/**
 * 
 * Esta clase es del usuario sin registrar
 *
 * @author Pablo Sanchez, Mikel Risquez y Alberto Vicente
 *
 */
package pacopaquetes.usuarios;

public abstract class UsuarioSinRegistrar {

}