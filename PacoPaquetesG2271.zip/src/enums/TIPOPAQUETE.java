package enums;

/**
 * Enumerado de tipo de paquete
 */
public enum TIPOPAQUETE {
    NORMAL, FRAGIL, COMIDA, ESPECIAL
}