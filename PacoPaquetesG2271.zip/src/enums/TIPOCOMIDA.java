package enums;

/**
 * Enumerado de tipo de comida
 */
public enum TIPOCOMIDA {
    NORMAL, CONGELADA, REFRIGERADA, NULL
}
